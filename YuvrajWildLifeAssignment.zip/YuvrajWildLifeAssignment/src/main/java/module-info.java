module org.example.yuvrajwildlifeassignment {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires com.fasterxml.jackson.databind;


    opens org.example.yuvrajwildlifeassignment to javafx.fxml;
    exports org.example.yuvrajwildlifeassignment;
}