package org.example.yuvrajwildlifeassignment;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class HelloController extends Application {

    private static final String API_URL_BREEDS = "https://api.thedogapi.com/v1/breeds";
    private static final String API_URL_IMAGES = "https://api.thedogapi.com/v1/images/search?breed_ids=";

    @FXML
    private ComboBox<String> breedComboBox;

    @FXML
    private Button searchButton;

    @FXML
    private VBox resultContainer;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        breedComboBox = new ComboBox<>();
        searchButton = new Button("Search Dog");
        resultContainer = new VBox();

        searchButton.setOnAction(event -> fetchDogImage());

        // Set up the layout
        VBox layout = new VBox(10, breedComboBox, searchButton, resultContainer);
        Scene scene = new Scene(layout, 400, 400);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Dog Breed Information");
        primaryStage.show();

        // Fetch dog breeds
        fetchBreeds();
    }

    private void fetchBreeds() {
        new Thread(() -> {
            try {
                String response = makeApiRequest(API_URL_BREEDS);
                if (response != null) {
                    handleBreedsResponse(response);
                } else {
                    showError("Error", "No breeds data found.");
                }
            } catch (Exception e) {
                e.printStackTrace();
                showError("Error", "An error occurred while fetching breed data.");
            }
        }).start();
    }

    private String makeApiRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");  // No headers or API key needed
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);

        if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
            try (InputStream responseStream = connection.getInputStream()) {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode rootNode = mapper.readTree(responseStream);
                return rootNode.toString();
            }
        } else {
            throw new Exception("HTTP error code: " + connection.getResponseCode());
        }
    }

    private void handleBreedsResponse(String response) {
        Platform.runLater(() -> {
            try {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode rootNode = mapper.readTree(response);

                // Debug the response to check its structure
                System.out.println("Breeds API Response: " + rootNode);

                // Populate the ComboBox with dog breed names
                for (JsonNode breed : rootNode) {
                    String breedName = breed.path("name").asText();
                    System.out.println("Breed: " + breedName); // Check what breed names are fetched
                    breedComboBox.getItems().add(breedName);
                }
            } catch (Exception e) {
                e.printStackTrace();
                showError("Error", "Error occurred while processing the breed data.");
            }
        });
    }

    private void fetchDogImage() {
        String selectedBreed = breedComboBox.getValue();

        if (selectedBreed == null || selectedBreed.isEmpty()) {
            selectedBreed = "bulldog"; // Default breed
        }

        String breedId = getBreedIdFromName(selectedBreed);
        if (!breedId.isEmpty()) {
            String urlString = API_URL_IMAGES + breedId;
            new Thread(() -> {
                try {
                    String response = makeApiRequest(urlString);
                    if (response != null) {
                        handleImageResponse(response);
                    } else {
                        showError("Error", "No image found for the selected breed.");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    showError("Error", "An error occurred while fetching dog image.");
                }
            }).start();
        } else {
            showError("Error", "Invalid breed selected.");
        }
    }

    private String getBreedIdFromName(String breedName) {
        try {
            String response = makeApiRequest(API_URL_BREEDS);
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(response);

            for (JsonNode breed : rootNode) {
                String name = breed.path("name").asText();
                if (name.equalsIgnoreCase(breedName)) {
                    return breed.path("id").asText();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private void handleImageResponse(String response) {
        Platform.runLater(() -> {
            try {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode rootNode = mapper.readTree(response);

                if (rootNode.isArray() && rootNode.size() > 0) {
                    JsonNode image = rootNode.get(0);
                    String imageUrl = image.path("url").asText();

                    // Display image
                    resultContainer.getChildren().clear();
                    resultContainer.getChildren().add(new javafx.scene.image.ImageView(imageUrl));
                } else {
                    showError("No Results", "No image found for the selected breed.");
                }
            } catch (Exception e) {
                e.printStackTrace();
                showError("Error", "Error occurred while processing the image data.");
            }
        });
    }

    private void showError(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
}
